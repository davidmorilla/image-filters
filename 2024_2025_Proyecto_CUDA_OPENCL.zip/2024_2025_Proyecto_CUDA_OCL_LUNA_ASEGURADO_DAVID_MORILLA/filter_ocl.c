#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <CL/cl.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb-master/stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb-master/stb_image_write.h"


typedef struct {
    char filter_name[50];
    int filter;
    float resize_factor;
} FilterOptions;

// BMP Headers
#pragma pack(push, 1)
typedef struct {
    uint16_t bfType;
    uint32_t bfSize;
    uint16_t bfReserved1;
    uint16_t bfReserved2;
    uint32_t bfOffBits;
} BMPFileHeader;

typedef struct {
    uint32_t biSize;
    int32_t biWidth;
    int32_t biHeight;
    uint16_t biPlanes;
    uint16_t biBitCount;
    uint32_t biCompression;
    uint32_t biSizeImage;
    int32_t biXPelsPerMeter;
    int32_t biYPelsPerMeter;
    uint32_t biClrUsed;
    uint32_t biClrImportant;
} BMPDIBHeader;
#pragma pack(pop)


int arg_parser(int argc, char **argv, FilterOptions *options);
void save_as_bmp(const char *filename, unsigned char *bmp_data, int width, int height);
const char *load_kernel_source(const char *filename);
void check_ocl_errors(cl_int ret);

//funcion para depuracion
void check_ocl_errors(cl_int ret){
    if (ret != CL_SUCCESS) {
    fprintf(stderr, "OpenCL Error: %d\n", ret);
    exit(-1);
}

}


int main(int argc, char **argv) {
    FilterOptions *flags = (FilterOptions *)malloc(sizeof(FilterOptions));
    if (arg_parser(argc, argv, flags) != 0) {
        return -1;
    }

    int width, height, channels;
    char *image_name = argv[1];
    unsigned char *image = stbi_load(image_name, &width, &height, &channels, 3);

    if (image == NULL || channels != 3) {
        fprintf(stderr, "Error loading the image\n");
        return 1;
    }

    int new_width = (int)(width * flags->resize_factor);
    int new_height = (int)(height * flags->resize_factor);
    unsigned char *resized_image = (unsigned char *)malloc(new_width * new_height * 3);
    int padding = (new_width * 3 + 3) & (~3) - new_width * 3;
    
    cl_platform_id platform_id;
    cl_device_id device_id;
    cl_context context;
    cl_command_queue command_queue;
    cl_program program;
    cl_kernel kernel;
    cl_int ret;
	
    ret = clGetPlatformIDs(1, &platform_id, NULL);
    check_ocl_errors(ret);
    ret = clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_GPU, 1, &device_id, NULL);
    check_ocl_errors(ret);

    context = clCreateContext(NULL, 1, &device_id, NULL, NULL, &ret);
    check_ocl_errors(ret);
    
    command_queue = clCreateCommandQueueWithProperties(context, device_id, 0, &ret);
    check_ocl_errors(ret);

    const char *source = load_kernel_source("filter_ocl_kernel.cl");
        
    program = clCreateProgramWithSource(context, 1, &source, NULL, &ret);
    check_ocl_errors(ret);
 
    ret = clBuildProgram(program, 1, &device_id, NULL, NULL, NULL);
    check_ocl_errors(ret);

    kernel = clCreateKernel(program, "prepare_and_resize_image_data", &ret);
    check_ocl_errors(ret);
    
    cl_mem d_image = clCreateBuffer(context, CL_MEM_READ_ONLY, width * height * 3, NULL, &ret);
    check_ocl_errors(ret);
    
    cl_mem d_resized_image = clCreateBuffer(context, CL_MEM_WRITE_ONLY, new_width * new_height * 3, NULL, &ret);
    check_ocl_errors(ret);
    
    ret = clEnqueueWriteBuffer(command_queue, d_image, CL_TRUE, 0, width * height * 3, image, 0, NULL, NULL);
    check_ocl_errors(ret);
    
    ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), &d_image);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), &d_resized_image);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 2, sizeof(int), &width);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 3, sizeof(int), &height);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 4, sizeof(int), &new_width);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 5, sizeof(int), &new_height);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 6, sizeof(float), &flags->resize_factor);
        check_ocl_errors(ret);
    ret = clSetKernelArg(kernel, 7, sizeof(int), &padding);
        check_ocl_errors(ret);
    

    size_t global_work_size[2] = {(new_width + 15) & (~15), (new_height + 15) & (~15)};
    size_t local_work_size[2] = {16, 16};

    ret = clEnqueueNDRangeKernel(command_queue, kernel, 2, NULL, global_work_size, local_work_size, 0, NULL, NULL);
    check_ocl_errors(ret);
    
    ret = clEnqueueReadBuffer(command_queue, d_resized_image, CL_TRUE, 0, new_width * new_height * 3, resized_image, 0, NULL, NULL);
    check_ocl_errors(ret);
    
    char image_w_filter_name[100];
    snprintf(image_w_filter_name, sizeof(image_w_filter_name), "%s_filter_%s", image_name, flags->filter_name);
    save_as_bmp(image_w_filter_name, resized_image, new_width, new_height);

    clReleaseMemObject(d_image);
    clReleaseMemObject(d_resized_image);
    clReleaseKernel(kernel);
    clReleaseProgram(program);
    clReleaseCommandQueue(command_queue);
    clReleaseContext(context);

    stbi_image_free(image);
    free(resized_image);
    free(flags);

    printf("Image saved to %s\n", image_w_filter_name);
    return 0;
}

int arg_parser(int argc, char **argv, FilterOptions *options) {
    if (strcmp(argv[1], "-help") == 0) {
        printf("Usage: %s imagename [filter options]\n", argv[0]);
        printf("Filter options:\n");
        printf("  -help            : Show this help message.\n");
        printf("  -resize N        : Resize the image by a factor N (0 < N <= 5).\n");
        exit(0);
    }

    if (argc < 3) {
        fprintf(stderr, "Usage: %s imagename [filter options]\n", argv[0]);
        return -1;
    }

    options->filter = -1;
    options->resize_factor = 0.0f;

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-resize") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: -resize flag requires a scaling factor (0 < N <= 5).\n");
                return -1;
            }
            options->resize_factor = atof(argv[++i]);
            if (options->resize_factor <= 0 || options->resize_factor > 5) {
                fprintf(stderr, "Error: Scaling factor must be in the range 0 < N <= 5.\n");
                return -1;
            }
            strcpy(options->filter_name, "resize");
            options->filter = 10;
        } else {
            fprintf(stderr, "Error: Unknown flag or argument %i: %s\n", i, argv[i]);
            return -1;
        }
    }

    if (options->filter == -1) {
        fprintf(stderr, "Error: No filter option provided.\n");
        return -1;
    }

    return 0;
}

void save_as_bmp(const char *filename, unsigned char *bmp_data, int width, int height) {
    int row_padded = (width * 3 + 3) & (~3);
    int padding = row_padded - width * 3;

    BMPFileHeader fileHeader;
    BMPDIBHeader dibHeader;

    fileHeader.bfType = 0x4D42;
    fileHeader.bfSize = sizeof(BMPFileHeader) + sizeof(BMPDIBHeader) + row_padded * height;
    fileHeader.bfReserved1 = 0;
    fileHeader.bfReserved2 = 0;
    fileHeader.bfOffBits = sizeof(BMPFileHeader) + sizeof(BMPDIBHeader);

    dibHeader.biSize = sizeof(BMPDIBHeader);
    dibHeader.biWidth = width;
    dibHeader.biHeight = -height;
    dibHeader.biPlanes = 1;
    dibHeader.biBitCount = 24;
    dibHeader.biCompression = 0;
    dibHeader.biSizeImage = row_padded * height;
    dibHeader.biXPelsPerMeter = 2835;
    dibHeader.biYPelsPerMeter = 2835;
    dibHeader.biClrUsed = 0;
    dibHeader.biClrImportant = 0;

    FILE *file = fopen(filename, "wb");
    if (!file) {
        perror("Could not open file");
        return;
    }

    fwrite(&fileHeader, sizeof(BMPFileHeader), 1, file);
    fwrite(&dibHeader, sizeof(BMPDIBHeader), 1, file);
    fwrite(bmp_data, row_padded * height, 1, file);
    fclose(file);

    printf("Image saved to %s\n", filename);
}

const char *load_kernel_source(const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Could not open kernel source file.");
        return NULL;
    }

    fseek(file, 0, SEEK_END);
    long length = ftell(file);
    fseek(file, 0, SEEK_SET);

    char *source = (char *)malloc(length + 1);
    fread(source, 1, length, file);
    source[length] = '\0';
    fclose(file);

    return source;
}

